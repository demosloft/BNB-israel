<div class="fav_wrapper">
    <div id="contact_host"  data-postid="<?php esc_attr(the_ID());?>">
        <?php esc_html_e('CONTACT OWNER','wprentals');?><i class="far fa-envelope"></i>
    </div>                 
</div>