<?php $show_compare=1;?>
<span class="entry-title listing_loader_title"><?php esc_html_e('Your search results','wprentals');?></span>
<div class="loader-inner ball-pulse" id="internal-loader">
    <div class="double-bounce1"></div>
    <div class="double-bounce2"></div>
</div>

<div id="listing_ajax_container">
</div>