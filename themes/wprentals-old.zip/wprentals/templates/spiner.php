<div class="loader-inner ball-pulse" id="listing_loader">
    <div class="double-bounce1"></div>
    <div class="double-bounce2"></div>
</div>