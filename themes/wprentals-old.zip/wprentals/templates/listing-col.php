<?php  
$post_id=$post->ID; 
$guest_list= wpestate_get_guest_dropdown();
?>


<?php   //get_template_part ('/templates/social_share_icons');?>

