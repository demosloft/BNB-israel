Theme Name: WpRentals
Theme URI: http://themeforest.net/user/annapx
Description: Ultimate WordPress Theme created by WP Estate for accomodation booking. WP Rentals is clean, flexible, fully responsive and retina Ready. Its smart settings allows you to build outstanding renting websites easy and fast.
Version: 1.00
Author: http://wpestate.org/
Author URI: http://themeforest.net/user/annapx
Text Domain: wpestate
Tags: white, one-column, two-columns,left-sidebar, right-sidebar, fluid-layout , custom-menu, theme-options, translation-ready
License: GNU General Public License v2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html

For help files go here http://help.wprentals.net/